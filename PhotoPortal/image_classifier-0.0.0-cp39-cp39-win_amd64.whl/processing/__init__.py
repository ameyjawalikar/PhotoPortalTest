__all__ = [
    'Bluriness_Detection',
    'darkness_detection',
    'views'
]
