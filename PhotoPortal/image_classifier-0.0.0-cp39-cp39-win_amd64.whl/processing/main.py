from logic import main      # this comes from a compiled binary

main ()
